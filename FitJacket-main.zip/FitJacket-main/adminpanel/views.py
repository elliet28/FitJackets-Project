from django.shortcuts import render

# Create your exercise_views here.
